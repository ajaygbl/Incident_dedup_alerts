# Alert correlation demo — portable bundle

Everything needed to run this on another Mac. Copy the whole folder across and run `./setup.sh`.

## What you need on the demo laptop

| | Needed? | Why |
| - | - | - |
| **Homebrew** | Yes | installs the two services |
| **Grafana** | Yes — `setup.sh` installs it | the UI and the alerting engine |
| **Prometheus** | Yes — `setup.sh` installs it | scrapes the demo app |
| **Python 3** | Yes — ships with macOS | runs the demo app; no pip packages |
| **Node / Yarn** | **No** | both plugin builds are already compiled; `plugin/` holds them |
| **Network** | Only for `brew install` | the demo itself is entirely local |

Node and Yarn are only needed to *change* the plugin's code. Running it, and switching the
mitigation grace period with `./grace.sh`, both work off the compiled builds in `plugin/`.

## Setup

```bash
./setup.sh
```

Installs Grafana and Prometheus if missing, writes the config, copies the plugin in, provisions
the datasource / alert rule / contact point / notification policy, starts all three services,
and enables the app.

Then open <http://localhost:3000/a/alert-ack-app> — login `admin` / `admin`.

Check a machine that is already set up:

```bash
./setup.sh --check   # are the services up?  (fast, shallow)
./smoke.sh           # does the whole pipeline work?  (~2 min, end to end)
./status.sh          # what is the plugin doing right now?
./status.sh -w       # ...refreshed every 5s
./grace.sh           # which mitigation grace period is installed?
```

`--check` only confirms the services respond. **`smoke.sh` is the one that matters** — it
verifies Prometheus is scraping, Grafana can query the datasource, the alert rule is
provisioned, an injected fault actually fires an alert, and the notification reaches the sink.
Run it the morning of the demo. It covers everything except the browser flow, which needs the
plugin tab open and has to be checked by hand.

## What's in here

```
setup.sh                    one-shot install and start
reset.sh                    back to a clean slate between runs
status.sh                   firing alerts, tracking rows, active silences
smoke.sh                    end-to-end pipeline test
grace.sh                    switch the mitigation grace period (1m / 30m)
prometheus.yml              scrape config (5s interval, targets shopdemo)
app/shopdemo.py             fake checkout service + fault injection + notification sink
app/incident-*.txt          sample analysis docs to upload
plugin/alert-ack-app/          the compiled plugin, 30-minute grace (default)
plugin/alert-ack-app-grace1m/  same plugin, 1-minute grace, for demoing the lapse
provisioning/
  datasources/metrics.yaml      Prometheus datasource, uid must stay "metrics"
  alerting/alert-rules.yaml     the Checkout error rate rule
  alerting/contact-points.yaml  demo-sink webhook -> localhost:8000/notify
  alerting/policies.yaml        group_wait 0s, repeat_interval 4h, grouped by all four labels
  plugins/alert-ack-app.yaml    enables the app
```

## Running the demo

**Always reset first**, then keep the plugin tab open throughout — correlation runs in the
page's refresh loop.

**1. One alert, notifies normally**

```bash
curl -X POST 'localhost:8000/fault?platform=web&currency=EUR&instrument=upi&error_rate=0.75&seconds=3600'
```

Appears in ~30s, unmuted, verdict "No matching open incident". Check it was delivered:

```bash
curl -s localhost:8000/notifications | python3 -m json.tool
```

**2. Declare the incident** — click **Mark incident** → `INC-1`.

**3. Upload the scope** — click **Upload .txt**, pick `app/incident-upi.txt`. Wait for the green
**✓ scope: instrument=upi** line, then click **Save doc**. If you don't see both, it hasn't saved.

**4. Widen the outage — the payoff**

```bash
curl -X POST 'localhost:8000/fault?instrument=upi&currency=EUR&error_rate=0.75&seconds=3600'
```

New UPI alerts arrive already marked `INC-1` and muted, each with a verdict citing the doc. The
notification list stays where it was.

**5. Show it doesn't over-match**

```bash
curl -X POST 'localhost:8000/fault?instrument=card&currency=EUR&error_rate=0.75&seconds=3600'
```

Card alerts appear **unmuted** and do notify. This is the step worth showing anyone skeptical —
it is easy to build something that quietly mutes everything.

**6. Mitigation window** — click **Mitigated**. Suppression drops from 4 hours to 30 minutes and
a countdown appears in the row. It lapses on its own, so a fix that didn't hold re-alerts.

**Status is a property of the incident, not of the row you clicked.** Clicking Mitigated or
Resolved on any alert in INC-1 applies to every alert in INC-1 — the row says so when there is
more than one. Resolving from one row while its siblings stayed muted was the behaviour this
replaced.

Each incident-related alert is held by **two** silences, and both move together:

| | matchers | created by |
| - | - | - |
| scope silence | `alertname` + the doc's dimensions | saving the analysis doc |
| per-alert silence | that alert's full label set | the auto-correlator, one per alert |

That matters because either one alone keeps the alert suppressed. Run `./status.sh` after each
click:

| Click | `status.sh` shows |
| - | - |
| after **Save doc** | the scope silence and one per-alert silence each `ends in ~239.9 min` |
| **Mitigated** | every one of them pulled in to `ends in ~29.9 min` |
| grace lapses | `ACTIVE SILENCES  (none)`, rows flip to **resolved**, nothing notifies |
| **Resolved** | `ACTIVE SILENCES  (none)`, immediately |

The silences are *rescheduled*, not deleted and recreated, so their matchers are untouched and
the incident keeps its scope. Mitigation can only shorten the window, never widen what it
covers.

**Releasing is silent, and that is the design.** When suppression ends — whether by resolving
or by the grace period lapsing — every alert in the incident is un-muted and its row is marked
**resolved**. No notification is sent for those alerts, even though several of them are still
firing.

That is the whole objective: **one notification per incident, not one per alert in it.** The
mutes exist to stop the duplicates; lifting them at the end is housekeeping, not an escalation,
and it must not turn into the very notification storm the mutes prevented.

`repeat_interval: 4h` in `provisioning/alerting/policies.yaml` is what guarantees it. Expiring
a silence does not notify by itself: Alertmanager only re-runs a group through the pipeline
when the group's alerts change or `repeat_interval` elapses, and a silence lapsing is neither.
Shorten that interval and releasing the mutes *does* notify — so leave it long.

Verified both halves on a live stack:

| | |
| - | - |
| alert muted under an incident, then released while still firing | **0 notifications** |
| brand-new platform/currency/instrument combination firing after that | **notifies at once** |

The second row is why a long `repeat_interval` costs you nothing. A new combination is a new
aggregation group, it has never notified, and `group_wait` is `0s` — so a genuinely different
problem still pages immediately.

**The trade-off, stated plainly:** if the fix did not hold and the *same* alerts keep firing,
nothing pages again. You find out from the plugin, not from a notification. An alert that
resolves and then re-fires does notify, because that is a change to the group — so real
recurrence is still caught. If you would rather be paged on a failed fix, shorten
`repeat_interval`, and accept duplicates for the same incident.

**7. Seeing the lapse itself** — 30 minutes is too long to watch, so a 1-minute build ships
alongside the default:

```bash
./grace.sh 0     # no grace: Mitigated un-mutes and resolves immediately
./grace.sh 1     # 1-minute grace, for demoing the lapse live
./grace.sh 30    # back to the real policy value
./grace.sh       # which one is installed?
```

Pick by what you want **Mitigated** to mean. At `0` it is terminal: click it and the incident's
alerts are un-muted and marked resolved on the spot. At `1` or `30` it holds suppression for
that long first, then does the same thing on its own. None of them notify.

Both are already compiled, so switching needs no Node or Yarn. It restarts Grafana and takes
about 15 seconds; **hard-refresh the plugin tab afterwards** (Cmd-Shift-R), because Grafana
cache-busts by plugin version and the two builds carry different ones.

On the 1-minute build: click **Mitigated**, watch the row's countdown run down, and a minute
later the mutes drop. Within one refresh (10s) `./status.sh` shows `ACTIVE SILENCES  (none)`
and the rows read **resolved**. The notification list does not move. Re-trigger a *different*
combination and it arrives un-muted and notifies, which is how you show the incident is really
closed rather than still swallowing everything.

Switch back to `30` before showing the real policy — the 1-minute value is a demo aid, not a
recommendation, and someone will ask.

## Fault injection reference

```bash
curl -X POST 'localhost:8000/fault?<scope>&error_rate=0.75&seconds=3600'
curl -s     localhost:8000/faults          # what is currently broken
curl -X POST localhost:8000/clear          # stop everything
```

Case matters:

| | Case | Values |
| - | - | - |
| `currency` | **UPPERCASE** | `USD` `EUR` `INR` `GBP` |
| `instrument` | lowercase | `card` `upi` `wallet` `netbanking` |
| `platform` | lowercase | `web` `ios` `android` |

Any dimension you leave out means "all of them", so `instrument=upi` alone trips 12 alerts.

## Things that will bite you

- **Keep the plugin tab open.** Correlation runs in the browser. Closed or heavily backgrounded
  tab means nothing correlates.
- **shopdemo is not a managed service.** It won't survive a reboot. Restart with
  `cd app && nohup python3 shopdemo.py > ../shopdemo.log 2>&1 &`
- **Port 3000, 8000 and 9090 must be free.**
- **If you edit and rebuild the plugin**, bump `version` in its `package.json` and restart
  Grafana — Grafana cache-busts by plugin version, so without a bump the browser keeps the old
  bundle however hard you refresh.
- **Alerts take ~30s to fire** and ~30s to clear after a fault is removed. Don't rush the demo.
- **Re-firing the *same* combination won't re-notify straight away.** The notification policy's
  `group_interval` is 1 minute, so a group that just notified is held before it notifies again.
  If you rehearse with `web/EUR/upi` and then demo with it, the live notification may not
  appear. Either rehearse with a different combination, or allow a minute between runs.
- **Un-muting does not notify, and that is intended.** Don't read a quiet notification list
  after the grace period as a broken demo. Silence expiry and notification are separate
  mechanisms; see the `repeat_interval` note above.
- **Don't shorten `repeat_interval`.** It looks like a harmless demo tweak and it silently
  turns the end of every incident into a burst of notifications.

## Restoring the laptop afterwards

```bash
brew services stop grafana prometheus
pkill -f shopdemo.py
# configs were backed up in place
cp $(brew --prefix)/etc/grafana/grafana.ini.orig $(brew --prefix)/etc/grafana/grafana.ini
cp $(brew --prefix)/etc/prometheus.yml.orig      $(brew --prefix)/etc/prometheus.yml
rm -rf $(brew --prefix)/var/lib/grafana/plugins/alert-ack-app
rm -f  $(brew --prefix)/etc/grafana/provisioning/alerting/{alert-rules,contact-points,policies}.yaml
rm -f  $(brew --prefix)/etc/grafana/provisioning/datasources/metrics.yaml
rm -f  $(brew --prefix)/etc/grafana/provisioning/plugins/alert-ack-app.yaml
```

## Note on provisioning

`setup.sh` sets `provisioning = <brew prefix>/etc/grafana/provisioning` in `grafana.ini`.

Grafana ships that setting commented out, where it defaults to `conf/provisioning` **relative
to the homepath** — i.e. inside the Homebrew Cellar. Files written to `etc/grafana/provisioning`
without changing that setting are silently ignored: no error, Grafana just never reads them.
Pointing it at `etc/` also means a `brew upgrade grafana` cannot wipe the config.

Because the alert rule now comes from a file, Grafana marks it provisioned and read-only in the
UI. That is fine for the demo; to edit it, change `provisioning/alerting/alert-rules.yaml` and
restart Grafana.
