# Changelog

## 0.1.0

- Initial scaffold: firing alert list with acknowledge / un-acknowledge.
