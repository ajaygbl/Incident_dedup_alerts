# Alert Ack

Lists firing Grafana-managed alerts and lets you acknowledge them, recording who acked and when.

## How acks are stored

Acks are **Grafana annotations**, not a separate database. Grafana stamps the author and
creation time itself, and annotation tags are queryable, so shared and attributed ack state
needs no backend plugin. See `src/api/acks.ts`.

Each ack carries two tags:

```
alert-ack                       scopes the annotation to this plugin
ack:<fingerprint>:<triggeredAt> identifies the alert incident
```

## The ack key

Acks are keyed on `fingerprint + incident start`, never fingerprint alone. A fingerprint is a
hash of the label set, so an alert that fires, resolves, and fires again keeps the same one —
keying on it alone would make an old ack silently apply to a new incident.

## Known limits

- **Polling misses short-lived alerts.** Alerts that fire and resolve between two 10s polls
  never appear. Catching every alert needs an Alertmanager webhook receiver, which needs a
  backend.
- **No server-side uniqueness.** Simultaneous acks create two annotations; reads collapse
  duplicates and keep the earliest.
- Acks share Grafana's annotations table with dashboard annotations.

## Development

```bash
yarn build     # or: yarn dev, to watch
yarn run check # format, typecheck, test
```
