#!/usr/bin/env python3
"""
Fake checkout service that emits Prometheus metrics across three dimensions:
platform (web / ios / android), currency (USD / EUR / INR / GBP) and
instrument (card / upi / wallet / netbanking).

Standard library only -- no pip install. Python 3.9 compatible.

    python3 shopdemo.py              # serves :8000/metrics

Traffic runs continuously in the background at a per-platform base rate, with a small
baseline error rate. Faults are injected over HTTP so a demo can *cause* an alert on
command rather than waiting for one:

    curl -X POST 'localhost:8000/fault?platform=ios&error_rate=0.6&seconds=600'
    curl -X POST 'localhost:8000/fault?currency=EUR&error_rate=0.5&seconds=600'
    curl -X POST 'localhost:8000/fault?platform=web&currency=USD&error_rate=0.7'
    curl -X POST localhost:8000/clear          # drop all faults
    curl localhost:8000/faults                 # list active faults

A fault scoped to one dimension breaks every combination beneath it, which is what makes
"one incident, several alerts" demonstrable: an outage scoped to instrument=upi trips every
platform and currency that uses UPI at once. Setting several scopes narrows the blast radius
to just that combination.
"""

import json
import random
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse

PLATFORMS = ["web", "ios", "android"]
CURRENCIES = ["USD", "EUR", "INR", "GBP"]
INSTRUMENTS = ["card", "upi", "wallet", "netbanking"]

# Rough shape of real traffic: web heaviest, android lightest.
PLATFORM_WEIGHT = {"web": 1.0, "ios": 0.6, "android": 0.35}
CURRENCY_WEIGHT = {"USD": 1.0, "EUR": 0.5, "INR": 0.4, "GBP": 0.2}
INSTRUMENT_WEIGHT = {"card": 1.0, "upi": 0.6, "wallet": 0.3, "netbanking": 0.2}

# Requests per second at weight 1.0, before per-dimension weighting.
BASE_RPS = 12.0

# Every service has some floor of genuine errors; without it a demo alert on
# "error rate > 0" fires constantly and teaches nothing.
BASELINE_ERROR_RATE = 0.01

TICK_SECONDS = 1.0

_lock = threading.Lock()
# (platform, currency, status) -> count
_requests = {}
# (platform, currency) -> accumulated seconds, and request count, for an average latency gauge
_latency_sum = {}
_latency_count = {}
_faults = []
_started_at = time.time()
# Alert notifications Grafana has delivered here, newest last. Stands in for Slack/email so
# the demo can show, concretely, which alerts got through and which were muted first.
_notifications = []


def _bump(table, key, amount):
    table[key] = table.get(key, 0) + amount


class Fault(object):
    """An injected elevation of the error rate, optionally scoped to one dimension."""

    def __init__(self, platform, currency, instrument, error_rate, expires_at, latency_ms):
        self.platform = platform
        self.currency = currency
        self.instrument = instrument
        self.error_rate = error_rate
        self.expires_at = expires_at
        self.latency_ms = latency_ms

    def matches(self, platform, currency, instrument):
        if self.platform and self.platform != platform:
            return False
        if self.currency and self.currency != currency:
            return False
        if self.instrument and self.instrument != instrument:
            return False
        return True

    def active(self, now):
        return self.expires_at is None or self.expires_at > now

    def describe(self):
        return {
            "platform": self.platform or "*",
            "currency": self.currency or "*",
            "instrument": self.instrument or "*",
            "error_rate": self.error_rate,
            "latency_ms": self.latency_ms,
            "expires_in_seconds": (None if self.expires_at is None else max(0, int(self.expires_at - time.time()))),
        }


def _error_rate_for(platform, currency, instrument, now):
    """Highest matching fault wins, so overlapping faults don't quietly cancel out."""
    rate = BASELINE_ERROR_RATE
    extra_latency = 0.0
    for fault in _faults:
        if fault.active(now) and fault.matches(platform, currency, instrument):
            rate = max(rate, fault.error_rate)
            extra_latency = max(extra_latency, fault.latency_ms)
    return rate, extra_latency


def _generate_traffic():
    """One tick of synthetic traffic across every platform/currency pair."""
    while True:
        now = time.time()
        with _lock:
            # Drop expired faults so /faults stays honest.
            _faults[:] = [f for f in _faults if f.active(now)]

            for platform in PLATFORMS:
                for currency in CURRENCIES:
                    for instrument in INSTRUMENTS:
                        weight = (
                            PLATFORM_WEIGHT[platform] * CURRENCY_WEIGHT[currency] * INSTRUMENT_WEIGHT[instrument]
                        )
                        expected = BASE_RPS * weight * TICK_SECONDS
                        # Poisson-ish jitter keeps the graphs from looking synthetic.
                        count = max(0, int(random.gauss(expected, max(1.0, expected * 0.25))))
                        if count == 0:
                            continue

                        error_rate, extra_latency = _error_rate_for(platform, currency, instrument, now)
                        errors = sum(1 for _ in range(count) if random.random() < error_rate)
                        successes = count - errors

                        key = (platform, currency, instrument)
                        if successes:
                            _bump(_requests, key + ("success",), successes)
                        if errors:
                            _bump(_requests, key + ("error",), errors)

                        base_latency = 0.12 if platform == "web" else 0.2
                        latency = (base_latency + extra_latency / 1000.0) * count
                        _bump(_latency_sum, key, latency)
                        _bump(_latency_count, key, count)

        time.sleep(TICK_SECONDS)


def _render_metrics():
    lines = []
    lines.append("# HELP checkout_requests_total Checkout requests by platform, currency and status.")
    lines.append("# TYPE checkout_requests_total counter")
    with _lock:
        for (platform, currency, instrument, status), value in sorted(_requests.items()):
            lines.append(
                'checkout_requests_total{platform="%s",currency="%s",instrument="%s",status="%s"} %d'
                % (platform, currency, instrument, status, value)
            )

        lines.append("# HELP checkout_latency_seconds_sum Accumulated checkout latency in seconds.")
        lines.append("# TYPE checkout_latency_seconds_sum counter")
        for (platform, currency, instrument), value in sorted(_latency_sum.items()):
            lines.append(
                'checkout_latency_seconds_sum{platform="%s",currency="%s",instrument="%s"} %.3f'
                % (platform, currency, instrument, value)
            )

        lines.append("# HELP checkout_latency_seconds_count Checkout requests contributing to the latency sum.")
        lines.append("# TYPE checkout_latency_seconds_count counter")
        for (platform, currency, instrument), value in sorted(_latency_count.items()):
            lines.append(
                'checkout_latency_seconds_count{platform="%s",currency="%s",instrument="%s"} %d'
                % (platform, currency, instrument, value)
            )

        lines.append("# HELP shopdemo_active_faults Number of fault injections currently active.")
        lines.append("# TYPE shopdemo_active_faults gauge")
        lines.append("shopdemo_active_faults %d" % len([f for f in _faults if f.active(time.time())]))

    lines.append("# HELP shopdemo_uptime_seconds Seconds since this process started.")
    lines.append("# TYPE shopdemo_uptime_seconds gauge")
    lines.append("shopdemo_uptime_seconds %.1f" % (time.time() - _started_at))
    return "\n".join(lines) + "\n"


class Handler(BaseHTTPRequestHandler):
    def _send(self, code, body, content_type="text/plain; charset=utf-8"):
        payload = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def _json(self, code, obj):
        self._send(code, json.dumps(obj, indent=2) + "\n", "application/json")

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/metrics":
            self._send(200, _render_metrics())
        elif parsed.path == "/faults":
            with _lock:
                self._json(200, {"faults": [f.describe() for f in _faults if f.active(time.time())]})
        elif parsed.path == "/notifications":
            with _lock:
                self._json(200, {"count": len(_notifications), "notifications": _notifications[-50:]})
        elif parsed.path in ("/", "/health"):
            self._json(200, {"status": "ok", "uptime_seconds": round(time.time() - _started_at, 1)})
        else:
            self._json(404, {"error": "not found"})

    def do_POST(self):
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)

        if parsed.path == "/notify":
            length = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(length).decode("utf-8") if length else "{}"
            try:
                payload = json.loads(raw)
            except ValueError:
                payload = {"unparseable": raw[:500]}
            received = time.strftime("%H:%M:%S")
            for alert in payload.get("alerts", []) or [{}]:
                labels = alert.get("labels", {})
                with _lock:
                    _notifications.append({
                        "at": received,
                        "status": alert.get("status", payload.get("status", "?")),
                        "alertname": labels.get("alertname", "?"),
                        "platform": labels.get("platform", "-"),
                        "currency": labels.get("currency", "-"),
                        "instrument": labels.get("instrument", "-"),
                    })
            self._json(200, {"ok": True})
            return

        if parsed.path == "/notifications/clear":
            with _lock:
                removed = len(_notifications)
                _notifications[:] = []
            self._json(200, {"cleared": removed})
            return

        if parsed.path == "/clear":
            with _lock:
                removed = len(_faults)
                _faults[:] = []
            self._json(200, {"cleared": removed})
            return

        if parsed.path != "/fault":
            self._json(404, {"error": "not found"})
            return

        platform = (query.get("platform") or [None])[0]
        currency = (query.get("currency") or [None])[0]
        instrument = (query.get("instrument") or [None])[0]
        if platform and platform not in PLATFORMS:
            self._json(400, {"error": "unknown platform", "allowed": PLATFORMS})
            return
        if currency and currency not in CURRENCIES:
            self._json(400, {"error": "unknown currency", "allowed": CURRENCIES})
            return
        if instrument and instrument not in INSTRUMENTS:
            self._json(400, {"error": "unknown instrument", "allowed": INSTRUMENTS})
            return

        try:
            error_rate = float((query.get("error_rate") or ["0.5"])[0])
            latency_ms = float((query.get("latency_ms") or ["0"])[0])
            seconds_raw = (query.get("seconds") or ["600"])[0]
            seconds = None if seconds_raw in ("0", "none", "forever") else float(seconds_raw)
        except ValueError:
            self._json(400, {"error": "error_rate, latency_ms and seconds must be numbers"})
            return

        if not 0.0 <= error_rate <= 1.0:
            self._json(400, {"error": "error_rate must be between 0 and 1"})
            return

        fault = Fault(
            platform=platform,
            currency=currency,
            instrument=instrument,
            error_rate=error_rate,
            expires_at=None if seconds is None else time.time() + seconds,
            latency_ms=latency_ms,
        )
        with _lock:
            _faults.append(fault)
        self._json(200, {"injected": fault.describe()})

    def log_message(self, fmt, *args):
        # Quiet: Prometheus scrapes every few seconds and would flood the terminal.
        pass


def main():
    threading.Thread(target=_generate_traffic, daemon=True).start()
    server = HTTPServer(("0.0.0.0", 8000), Handler)
    print("shopdemo listening on http://localhost:8000")
    print("  metrics : http://localhost:8000/metrics")
    print("  inject  : curl -X POST 'localhost:8000/fault?platform=ios&error_rate=0.6&seconds=600'")
    print("  clear   : curl -X POST localhost:8000/clear")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nstopping")


if __name__ == "__main__":
    main()
