#!/bin/bash
# Shows what the plugin is doing right now: firing alerts, their tracking rows, and every
# active silence with how long it has left.
#
#   ./status.sh         print once
#   ./status.sh -w      refresh every 5s until Ctrl-C
#
# Useful for verifying the Mitigated / Resolved buttons without waiting 30 minutes: click the
# button, run this, and watch the silence's remaining time drop from ~4h to ~30m (mitigated)
# or disappear entirely (resolved).
set -uo pipefail
A=(-s -u admin:admin)
G=http://localhost:3000

show() {
  echo "────────────────────────────────────────────────────────────  $(date +%H:%M:%S)"

  echo "ALERTS"
  curl "${A[@]}" "$G/api/alertmanager/grafana/api/v2/alerts" | python3 -c '
import json,sys
d=json.load(sys.stdin)
if not d:
    print("  (none firing)")
for a in sorted(d, key=lambda x: str(x["labels"].get("instrument"))):
    l=a["labels"]
    print("  %-8s %-4s %-11s %s" % (l.get("platform","-"), l.get("currency","-"),
                                     l.get("instrument","-"), a["status"]["state"]))'

  echo "TRACKING ROWS"
  curl "${A[@]}" "$G/api/annotations?tags=alert-record&type=annotation" | python3 -c '
import json,sys
rows=json.load(sys.stdin)
if not rows:
    print("  (none)")
for r in sorted(rows, key=lambda x: x["time"]):
    b=json.loads(r["text"]); lb=b.get("labels",{})
    scope = "scope-silence" if b.get("scopeSilenceId") else ("muted" if b.get("silenceId") else "-")
    print("  %-8s %-4s %-11s  %-6s %-12s %s" % (
        lb.get("platform","-"), lb.get("currency","-"), lb.get("instrument","-"),
        b.get("incidentId") or "-", b.get("status") or "-", scope))'

  echo "ACTIVE SILENCES"
  curl "${A[@]}" "$G/api/alertmanager/grafana/api/v2/silences" | python3 -c '
import json,sys,datetime
now=datetime.datetime.now(datetime.timezone.utc)
act=[s for s in json.load(sys.stdin) if s["status"]["state"]=="active"]
if not act:
    print("  (none)")
for s in act:
    end=datetime.datetime.fromisoformat(s["endsAt"].replace("Z","+00:00"))
    mins=(end-now).total_seconds()/60
    m={x["name"]:x["value"] for x in s["matchers"] if not x["name"].startswith("__") and x["name"]!="alertname"}
    label=", ".join("%s=%s"%(k,v) for k,v in m.items()) or "all"
    print("  %-34s ends in %5.1f min   %s" % (label, mins, s.get("comment","")[:46]))'

  echo "NOTIFICATIONS DELIVERED"
  curl -s http://localhost:8000/notifications | python3 -c '
import json,sys
d=json.load(sys.stdin)
if not d["notifications"]:
    print("  (none)")
for n in d["notifications"][-8:]:
    print("  %s %-8s %-8s %-4s %s" % (n["at"], n["status"], n["platform"], n["currency"], n.get("instrument","-")))'
}

if [ "${1:-}" = "-w" ]; then
  while true; do clear; show; sleep 5; done
else
  show
fi
