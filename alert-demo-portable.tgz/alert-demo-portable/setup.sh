#!/bin/bash
# Sets up the alert-correlation demo on a fresh Mac.
#
#   ./setup.sh          install, configure, start everything
#   ./setup.sh --check   verify a machine that is already set up
#
# Idempotent: every step is guarded, so re-running is safe.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BREW_PREFIX="$(brew --prefix 2>/dev/null || echo /opt/homebrew)"
GRAFANA_INI="$BREW_PREFIX/etc/grafana/grafana.ini"
GRAFANA_PROV="$BREW_PREFIX/etc/grafana/provisioning"
GRAFANA_PLUGINS="$BREW_PREFIX/var/lib/grafana/plugins"
PROM_YML="$BREW_PREFIX/etc/prometheus.yml"

log() { echo "==> $*"; }
fail() { echo "!!  $*" >&2; exit 1; }

check() {
  local ok=0
  for probe in "shopdemo http://localhost:8000/health" \
               "prometheus http://localhost:9090/-/healthy" \
               "grafana http://localhost:3000/api/health"; do
    set -- $probe
    code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 4 "$2" || echo 000)
    printf "  %-11s %s\n" "$1" "$code"
    [ "$code" = "200" ] || ok=1
  done
  printf "  %-11s " "plugin"
  curl -s -u admin:admin http://localhost:3000/api/plugins/alert-ack-app/settings \
    | python3 -c 'import json,sys
try:
    d=json.load(sys.stdin); print("enabled" if d.get("enabled") else "NOT ENABLED", "v"+d.get("info",{}).get("version","?"))
except Exception: print("NOT INSTALLED")' || ok=1
  return $ok
}

if [ "${1:-}" = "--check" ]; then
  log "checking services"
  check && log "all good" || fail "something is down — see above"
  exit 0
fi

command -v brew >/dev/null || fail "Homebrew required: https://brew.sh"

log "installing grafana + prometheus (skipped if present)"
brew list grafana >/dev/null 2>&1 || brew install grafana
brew list prometheus >/dev/null 2>&1 || brew install prometheus

log "configuring prometheus to scrape the demo app"
[ -f "$PROM_YML.orig" ] || cp "$PROM_YML" "$PROM_YML.orig" 2>/dev/null || true
cp "$HERE/prometheus.yml" "$PROM_YML"

log "pointing grafana at our provisioning directory"
# grafana.ini ships `;provisioning = conf/provisioning`, which resolves relative to the
# *homepath* (inside the Cellar), not to etc/. Writing files to etc/grafana/provisioning
# without this leaves them silently unread. Point it at a stable path outside the Cellar so
# a `brew upgrade grafana` cannot wipe it.
if ! grep -q "^provisioning = $GRAFANA_PROV" "$GRAFANA_INI"; then
  [ -f "$GRAFANA_INI.orig" ] || cp "$GRAFANA_INI" "$GRAFANA_INI.orig"
  python3 - "$GRAFANA_INI" "$GRAFANA_PROV" <<'PY2'
import sys
ini, prov = sys.argv[1], sys.argv[2]
s = open(ini).read()
needle = ';provisioning = conf/provisioning\n'
if needle not in s:
    raise SystemExit('could not find the provisioning template line in grafana.ini')
open(ini, 'w').write(s.replace(needle, needle + 'provisioning = %s\n' % prov, 1))
PY2
fi

log "allowing the unsigned plugin"
if ! grep -q '^allow_loading_unsigned_plugins.*alert-ack-app' "$GRAFANA_INI"; then
  [ -f "$GRAFANA_INI.orig" ] || cp "$GRAFANA_INI" "$GRAFANA_INI.orig"
  # Append under [plugins] rather than editing in place, so the stock file stays readable.
  python3 - "$GRAFANA_INI" <<'PY'
import sys
p = sys.argv[1]
s = open(p).read()
needle = ';allow_loading_unsigned_plugins =\n'
if needle not in s:
    raise SystemExit('could not find the [plugins] template line in grafana.ini')
open(p, 'w').write(s.replace(needle, needle + 'allow_loading_unsigned_plugins = alert-ack-app\n', 1))
PY
fi

log "installing the plugin"
mkdir -p "$GRAFANA_PLUGINS"
rm -rf "$GRAFANA_PLUGINS/alert-ack-app"
cp -R "$HERE/plugin/alert-ack-app" "$GRAFANA_PLUGINS/alert-ack-app"

log "provisioning datasource, alert rule, contact point and policy"
mkdir -p "$GRAFANA_PROV/alerting" "$GRAFANA_PROV/datasources" "$GRAFANA_PROV/plugins"
cp "$HERE/provisioning/alerting/"*.yaml      "$GRAFANA_PROV/alerting/"
cp "$HERE/provisioning/datasources/"*.yaml   "$GRAFANA_PROV/datasources/"
cp "$HERE/provisioning/plugins/"*.yaml       "$GRAFANA_PROV/plugins/"

log "starting the demo app on :8000"
pkill -f 'shopdemo.py' 2>/dev/null || true
( cd "$HERE/app" && nohup python3 shopdemo.py > "$HERE/shopdemo.log" 2>&1 & )

log "starting prometheus and grafana"
brew services restart prometheus >/dev/null
brew services restart grafana >/dev/null

log "waiting for grafana"
for _ in $(seq 1 60); do
  [ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 2 http://localhost:3000/api/health || echo 000)" = "200" ] && break
  sleep 1
done

# Provisioning registers the app but leaves it disabled in some Grafana versions.
curl -s -u admin:admin -X POST -H "Content-Type: application/json" \
  -d '{"enabled":true,"pinned":true,"jsonData":{}}' \
  http://localhost:3000/api/plugins/alert-ack-app/settings >/dev/null || true

echo
log "status"
check || true
echo
log "open http://localhost:3000/a/alert-ack-app  (admin / admin)"
log "trigger an alert:"
echo "    curl -X POST 'localhost:8000/fault?platform=web&currency=EUR&instrument=upi&error_rate=0.75&seconds=3600'"
