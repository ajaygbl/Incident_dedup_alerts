#!/bin/bash
# Returns the demo to a clean slate: no faults, no alerts, no tracking rows, no silences.
# Run this between demo runs.
set -euo pipefail
A=(-s -u admin:admin)
G=http://localhost:3000

echo "==> clearing faults and notifications"
curl -s -X POST localhost:8000/clear >/dev/null || true
curl -s -X POST localhost:8000/notifications/clear >/dev/null || true

echo "==> expiring silences"
curl "${A[@]}" "$G/api/alertmanager/grafana/api/v2/silences" \
  | python3 -c 'import json,sys;print("\n".join(s["id"] for s in json.load(sys.stdin) if s["status"]["state"]=="active"))' \
  | while read -r s; do [ -n "$s" ] && curl "${A[@]}" -X DELETE -o /dev/null "$G/api/alertmanager/grafana/api/v2/silence/$s"; done

echo "==> waiting for alerts to resolve"
for _ in $(seq 1 12); do
  n=$(curl "${A[@]}" "$G/api/alertmanager/grafana/api/v2/alerts" | python3 -c 'import json,sys;print(len(json.load(sys.stdin)))')
  echo "    $n firing"
  [ "$n" = "0" ] && break
  sleep 15
done

# Rows are deleted last: while alerts are still firing an open browser tab keeps recreating them.
echo "==> deleting tracking rows"
curl "${A[@]}" "$G/api/annotations?tags=alert-record&type=annotation" \
  | python3 -c 'import json,sys;print("\n".join(str(r["id"]) for r in json.load(sys.stdin)))' \
  | while read -r id; do [ -n "$id" ] && curl "${A[@]}" -X DELETE -o /dev/null "$G/api/annotations/$id"; done

echo "==> clean"
