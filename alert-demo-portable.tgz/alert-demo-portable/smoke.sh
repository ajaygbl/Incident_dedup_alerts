#!/bin/bash
# End-to-end smoke test: proves the whole pipeline works, not just that services respond.
#
#   ./smoke.sh
#
# Injects a fault, waits for the alert to fire, checks it was delivered to the sink, then
# cleans up after itself. Takes about two minutes.
#
# Covers everything EXCEPT correlation and auto-muting, which run in the browser and need the
# plugin tab open. Run this first; if it passes, the only thing left to verify by hand is the
# UI flow in README.md.
set -uo pipefail

A=(-s -u admin:admin)
G=http://localhost:3000
S=http://localhost:8000
PASS=0
FAIL=0

ok()   { printf "  \033[32mPASS\033[0m  %s\n" "$1"; PASS=$((PASS+1)); }
bad()  { printf "  \033[31mFAIL\033[0m  %s\n" "$1"; FAIL=$((FAIL+1)); }
note() { printf "        %s\n" "$1"; }

echo "==> 1. services"
for probe in "shopdemo $S/health" "prometheus http://localhost:9090/-/healthy" "grafana $G/api/health"; do
  set -- $probe
  [ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 "$2")" = "200" ] && ok "$1 responding" || bad "$1 not responding"
done

echo "==> 2. prometheus is scraping the demo app"
# --data-urlencode, not a raw query string: the braces and quotes in a PromQL selector
# are not URL-safe and Prometheus rejects them with a parse error.
up=$(curl -s --data-urlencode 'query=up{job="shopdemo"}' http://localhost:9090/api/v1/query \
  | python3 -c 'import json,sys
try:
    r=json.load(sys.stdin)["data"]["result"]; print(r[0]["value"][1] if r else "0")
except Exception: print("0")')
[ "$up" = "1" ] && ok "shopdemo target is up" || bad "shopdemo target is down (check prometheus.yml)"

series=$(curl -s --data-urlencode 'query=count(checkout_requests_total)' http://localhost:9090/api/v1/query \
  | python3 -c 'import json,sys
try:
    r=json.load(sys.stdin)["data"]["result"]; print(r[0]["value"][1] if r else "0")
except Exception: print("0")')
[ "${series%%.*}" -gt 0 ] 2>/dev/null && ok "checkout metrics present ($series series)" || bad "no checkout_requests_total series"

echo "==> 3. grafana can query the datasource"
code=$(curl "${A[@]}" -o /dev/null -w '%{http_code}' \
  "$G/api/datasources/proxy/uid/metrics/api/v1/query?query=up")
[ "$code" = "200" ] && ok "datasource 'metrics' queryable" || bad "datasource 'metrics' returned $code"

echo "==> 4. alert rule is provisioned"
rules=$(curl "${A[@]}" "$G/api/v1/provisioning/alert-rules" \
  | python3 -c 'import json,sys
try: print(len([r for r in json.load(sys.stdin) if r.get("title")=="Checkout error rate high"]))
except Exception: print(0)')
[ "$rules" -ge 1 ] 2>/dev/null && ok "alert rule found" || bad "alert rule missing"

echo "==> 5. plugin registered and enabled"
curl "${A[@]}" "$G/api/plugins/alert-ack-app/settings" | python3 -c 'import json,sys
try:
    d=json.load(sys.stdin)
    print("OK" if d.get("enabled") else "DISABLED", d.get("info",{}).get("version","?"))
except Exception: print("MISSING ?")' | {
  read -r state version
  [ "$state" = "OK" ] && ok "plugin enabled (v$version)" || bad "plugin $state"
}

echo "==> 6. clearing state before the live test"
curl -s -X POST "$S/clear" >/dev/null
curl -s -X POST "$S/notifications/clear" >/dev/null
note "waiting for any existing alerts to clear"
for _ in $(seq 1 10); do
  n=$(curl "${A[@]}" "$G/api/alertmanager/grafana/api/v2/alerts" | python3 -c 'import json,sys;print(len(json.load(sys.stdin)))')
  [ "$n" = "0" ] && break
  sleep 10
done

echo "==> 7. injecting a fault and waiting for the alert"
# Deliberately NOT the web/EUR/upi combination the demo script uses. Alertmanager's
# group_interval (1m) holds a repeat notification for a group that has just notified, so
# re-testing the demo's own combination gives a false failure.
curl -s -X POST "$S/fault?platform=android&currency=GBP&instrument=netbanking&error_rate=0.85&seconds=400" >/dev/null
fired=0
for _ in $(seq 1 12); do
  sleep 10
  n=$(curl "${A[@]}" "$G/api/alertmanager/grafana/api/v2/alerts" \
    | python3 -c 'import json,sys
d=json.load(sys.stdin)
print(len([a for a in d if a["labels"].get("instrument")=="netbanking" and a["labels"].get("currency")=="GBP"]))')
  if [ "$n" -ge 1 ] 2>/dev/null; then fired=1; break; fi
done
[ "$fired" = "1" ] && ok "alert fired within 2 minutes" || bad "alert never fired"

echo "==> 8. notification delivered to the sink"
delivered=0
for _ in $(seq 1 12); do
  sleep 10
  c=$(curl -s "$S/notifications" | python3 -c 'import json,sys
d=json.load(sys.stdin)
print(len([n for n in d["notifications"] if n.get("status")=="firing"]))')
  if [ "$c" -ge 1 ] 2>/dev/null; then delivered=1; break; fi
done
[ "$delivered" = "1" ] && ok "notification reached the sink" || bad "no firing notification delivered"

echo "==> 9. cleaning up"
curl -s -X POST "$S/clear" >/dev/null
curl -s -X POST "$S/notifications/clear" >/dev/null
curl "${A[@]}" "$G/api/annotations?tags=alert-record&type=annotation" \
  | python3 -c 'import json,sys;print("\n".join(str(r["id"]) for r in json.load(sys.stdin)))' \
  | while read -r id; do [ -n "$id" ] && curl "${A[@]}" -X DELETE -o /dev/null "$G/api/annotations/$id"; done
note "alerts will clear on their own in ~30s"

echo
printf "==> %d passed, %d failed\n" "$PASS" "$FAIL"
if [ "$FAIL" -gt 0 ]; then
  echo "    Pipeline is not ready — fix the failures above before demoing."
  exit 1
fi
echo "    Pipeline works. Still verify the browser flow by hand (README.md, steps 2-6)."
