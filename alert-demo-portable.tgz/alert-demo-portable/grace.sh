#!/bin/bash
# Switches the mitigation grace period between the two prebuilt plugin variants.
#
#   ./grace.sh 1     1 minute   -- for showing the suppression lapse live
#   ./grace.sh 30    30 minutes -- the real policy value (default after setup.sh)
#   ./grace.sh       show which one is installed
#
# Both variants are compiled and shipped in plugin/, so switching needs no Node or Yarn.
# They differ only in MITIGATION_GRACE_MINUTES and in their version string -- the differing
# version is what makes the browser drop the cached bundle, so don't "tidy" them to match.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BREW_PREFIX="$(brew --prefix 2>/dev/null || echo /opt/homebrew)"
PLUGINS="$BREW_PREFIX/var/lib/grafana/plugins"
TARGET="$PLUGINS/alert-ack-app"

log() { echo "==> $*"; }
fail() { echo "!!  $*" >&2; exit 1; }

installed() {
  [ -f "$TARGET/plugin.json" ] || { echo "not installed"; return; }
  python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["info"]["version"])' "$TARGET/plugin.json"
}

describe() {
  case "$(installed)" in
    *grace1m) echo "1 minute  (demo variant)" ;;
    "not installed") echo "not installed -- run ./setup.sh first" ;;
    *) echo "30 minutes  (default)" ;;
  esac
}

if [ $# -eq 0 ]; then
  echo "  grace period: $(describe)"
  echo "  plugin version: $(installed)"
  exit 0
fi

case "$1" in
  1|1m|fast)   SRC="$HERE/plugin/alert-ack-app-grace1m"; WANT="1 minute" ;;
  30|30m|real) SRC="$HERE/plugin/alert-ack-app";         WANT="30 minutes" ;;
  *) fail "usage: ./grace.sh [1|30]" ;;
esac

[ -d "$SRC" ] || fail "missing build: $SRC"
[ -d "$PLUGINS" ] || fail "grafana plugin dir not found -- run ./setup.sh first"

log "installing the $WANT build"
rm -rf "$TARGET"
cp -R "$SRC" "$TARGET"

log "restarting grafana"
brew services restart grafana >/dev/null

log "waiting for grafana"
for _ in $(seq 1 60); do
  [ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 2 http://localhost:3000/api/health || echo 000)" = "200" ] && break
  sleep 1
done

# A version change can leave the app registered but disabled; re-assert it.
curl -s -u admin:admin -X POST -H "Content-Type: application/json" \
  -d '{"enabled":true,"pinned":true,"jsonData":{}}' \
  http://localhost:3000/api/plugins/alert-ack-app/settings >/dev/null || true

echo
log "grace period: $(describe)"
log "plugin version: $(installed)"
log "now hard-refresh the plugin tab (Cmd-Shift-R) -- the old bundle is cached per version"
